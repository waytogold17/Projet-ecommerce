from flask import Flask
from flask import Flask,render_template
from .views import create_app
from .config import app
import os 






    
    
    
    
    
    
    
    
    
    # a simple page that says hell

    
    
    
    
    
    